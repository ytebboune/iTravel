import { View, Text, TouchableOpacity, ImageBackground, Image } from 'react-native';
import { useRouter } from 'expo-router';
import { useState } from 'react';
import { useAuth } from '@/providers/auth-provider';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';

export default function Login() {
  const router = useRouter();
  const { signIn } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleLogin = async () => {
    try {
      setIsLoading(true);
      await signIn(email, password);
      // La redirection est gérée par le AuthProvider
    } catch (error) {
      console.error('Erreur de connexion:', error);
      // TODO: Afficher un message d'erreur
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <ImageBackground
      source={require('../../assets/images/background.png')}
      style={{ flex: 1 }}
      resizeMode="cover"
    >
      <View className="flex-1 justify-center px-6">
        {/* Logo et titre */}
        <View className="items-center mb-8 mt-8">
          <Text className="text-4xl font-bold text-white mb-2" style={{ fontFamily: 'Manrope' }}>iTravel</Text>
          <Text className="text-xl text-white font-medium mb-2">Welcome back</Text>
        </View>
        {/* Formulaire */}
        <View className="bg-white/80 rounded-2xl p-6 shadow-lg">
          <Input
            placeholder="Email address"
            keyboardType="email-address"
            autoCapitalize="none"
            className="mb-4 bg-[#F7FAFC] border-primary text-base rounded-xl px-4 py-3"
            placeholderTextColor="#2D9560"
            value={email}
            onChangeText={setEmail}
          />
          <Input
            placeholder="Password"
            secureTextEntry
            className="mb-2 bg-[#F7FAFC] border-primary text-base rounded-xl px-4 py-3"
            placeholderTextColor="#2D9560"
            value={password}
            onChangeText={setPassword}
          />
          <Button 
            variant="primary" 
            className="mt-2 rounded-2xl py-3 text-base font-semibold"
            onPress={handleLogin}
            disabled={isLoading}
          >
            {isLoading ? 'Loading...' : 'Log in'}
          </Button>
          <TouchableOpacity className="mt-3 mb-2">
            <Text className="text-primary text-center text-base font-medium">Forgot password?</Text>
          </TouchableOpacity>
          {/* Séparateur */}
          <View className="flex-row items-center my-3">
            <View className="flex-1 h-px bg-gray-300" />
            <Text className="mx-2 text-gray-500 font-medium">OR</Text>
            <View className="flex-1 h-px bg-gray-300" />
          </View>
          {/* Boutons sociaux */}
          <TouchableOpacity className="flex-row items-center justify-center bg-white border border-gray-200 rounded-xl py-3 mb-3">
            <Image source={{ uri: 'https://upload.wikimedia.org/wikipedia/commons/5/53/Google_%22G%22_Logo.svg' }} style={{ width: 22, height: 22, marginRight: 8 }} />
            <Text className="text-base font-medium text-gray-800">Continue with Google</Text>
          </TouchableOpacity>
          <TouchableOpacity className="flex-row items-center justify-center bg-white border border-gray-200 rounded-xl py-3">
            <Image source={{ uri: 'https://upload.wikimedia.org/wikipedia/commons/f/fa/Apple_logo_black.svg' }} style={{ width: 22, height: 22, marginRight: 8 }} />
            <Text className="text-base font-medium text-gray-800">Continue with Apple</Text>
          </TouchableOpacity>
        </View>
        {/* Lien créer un compte */}
        <TouchableOpacity className="mt-6" onPress={() => router.push('/(auth)/register')}>
          <Text className="text-white text-center text-base font-medium underline">Create an account</Text>
        </TouchableOpacity>
      </View>
    </ImageBackground>
  );
} 