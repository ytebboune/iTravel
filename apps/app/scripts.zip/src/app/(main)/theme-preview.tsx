import { Text } from 'react-native';

export default function ThemePreviewScreen() {
  return <Text className="text-base">Test rendu</Text>;
} 