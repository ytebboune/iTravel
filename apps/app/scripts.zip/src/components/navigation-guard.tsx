import { useEffect } from 'react';
import { useRouter, useSegments, useRootNavigationState } from 'expo-router';
import { useAuth } from '@/providers/auth-provider';

export function NavigationGuard() {
  const { user } = useAuth();
  const segments = useSegments();
  const router = useRouter();
  const navigationState = useRootNavigationState();

  useEffect(() => {
    if (!navigationState?.key) return;

    const inAuthGroup = segments[0] === '(auth)';

    if (!user && !inAuthGroup) {
      // Rediriger vers la page de connexion si l'utilisateur n'est pas connecté
      router.replace('/(auth)');
    } else if (user && inAuthGroup) {
      // Rediriger vers la page d'accueil si l'utilisateur est connecté
      router.replace('/');
    }
  }, [user, segments, navigationState?.key]);

  return null;
} 